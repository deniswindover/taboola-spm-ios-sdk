//
//  TBLStoriesCollectionView.h
//  TaboolaSDK
//
//  Created by Karen Shaham Palman on 20/05/2021.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TBLStoriesCollectionView : UICollectionView

@end

NS_ASSUME_NONNULL_END
