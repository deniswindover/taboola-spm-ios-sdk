//
//  TBLDescriptionLabel.h
//  TaboolaView
//
//  Created by Tzufit Lifshitz on 11/23/17.
//  Copyright © 2017 Taboola. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TBLDescriptionLabel : UILabel

@end
