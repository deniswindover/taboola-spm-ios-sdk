//
//  TBLAdditionalViews.h
//  TaboolaSDK
//
//  Created by Karen Shaham Palman on 27/04/2022.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TBLAdditionalViews : NSObject

@end

NS_ASSUME_NONNULL_END
